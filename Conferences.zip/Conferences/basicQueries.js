


// ---- BACKLOG ----- // 

//ds.Person.all()
//ds.Person.find('name == Ricardo').conferences.name

////ds.Conferences.all()

//attendees = ds.Attended.find('ID is not null')
//attendees.ID + " " + attendees.person.name + " " + attendees.conference.name


//path = ds.Person.query('conferences.ID == :1', '3', {queryPath:true, queryPlan:true}).queryPath
//path

person = ds.Person.find('name eq Ricardo')
person.conferences.people.info


// REST
// http://127.0.0.1:8081/rest/Person/?$filter=%22conferences.name=JSEverywhere%22