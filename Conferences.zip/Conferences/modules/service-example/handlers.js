function statusHandler(request, response){
    response.statusCode = 200;
    
    return "ok";
}