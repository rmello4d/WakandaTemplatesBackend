﻿
include("./methods/Person/Person-events.js");
include("./methods/Person/Person-methods.js");