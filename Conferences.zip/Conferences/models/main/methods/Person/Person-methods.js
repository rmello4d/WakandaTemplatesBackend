

model.Person.methods.getFrequency = function(id) {
	
	
	return ds.Person(id).conferences.length
};

model.Person.methods.getFrequency.scope = "public"