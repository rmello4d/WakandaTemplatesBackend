

model.Person.info.onGet = function() {
	
	return 	"Name : " + this.name + "  " +
			"Telephone: " + this.tel;
};





model.Person.events.save = function(event) {
	
	if (this.name) 
		this.name = this.name.charAt(0).toUpperCase() + this.name.slice(1);

};




model.Person.tel.events.validate = function(event) {

};
