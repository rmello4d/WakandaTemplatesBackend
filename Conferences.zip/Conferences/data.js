


//ds.Attended.remove()

ds.Attended.all()


//ds.Person.all()
//ds.Conferences.all()


// 1. Create a list ATTENDED_LIST with name and conference
//ATTENDED_LIST = [{
//	    person: 'Ricardo', conf: 'JSEverywhere'
//	}, {
//	    person: 'Ricardo', conf: '4D Summit'
//	}, {
//	    person: 'Ricardo', conf: 'JSBrazil'
//	}, {
//	    person: 'Diana', conf: 'JSEverywhere'
//	}, {
//	    person: 'Zago', conf: 'Ng-conf'
//	}, {
//	    person: 'Jim', conf: 'JSEverywhere'
//	}];


//// 2. Add ATTENDED_LIST to the Attended dataclass
//ATTENDED_LIST.forEach(function(link) {

//    var attended = new ds.Attended();

//    attended.person = ds.Person.find('name = "' + link.person + '"');
//    attended.conference = ds.Conferences.find('name = "' + link.conf + '"');

//    attended.save();

//});


