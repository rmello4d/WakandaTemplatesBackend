
//exports.foo = 'bar';


generator = require("fakedata/generator");

generator;